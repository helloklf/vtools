#!/sbin/sh

if [ ! -d "/data/media/rom2/" ]; then
	mkdir /data/media/rom2
fi

if [ ! -f "/data/media/rom2/boot.img" ]; then
	dd if=/dev/block/bootdevice/by-name/boot of=/data/media/rom2/boot.img
fi

if [ ! -f "/data/media/rom2/system.img" ]; then
	rm -f /data/media/rom2/system.img
fi

if [ ! -f "/data/media/rom2/data.img" ]; then
	dd if=/dev/zero of=/data/media/rom2/data.img count=3100 bs=1048576
	mke2fs -F -t ext4 /data/media/rom2/data.img
fi

if [ ! -f "/data/media/rom2/boot1.img" ]; then
	dd if=/dev/block/bootdevice/by-name/boot of=/data/media/rom2/boot1.img
fi
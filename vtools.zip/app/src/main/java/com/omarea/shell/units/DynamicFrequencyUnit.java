package com.omarea.shell.units;

/**
 * Created by Hello on 2017/11/01.
 */

public class DynamicFrequencyUnit {
}

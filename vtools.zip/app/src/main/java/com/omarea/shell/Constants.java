package com.omarea.shell;

import com.omarea.vboot.BuildConfig;

/**
 * Created by Hello on 2017/11/01.
 */

public interface Constants {
}

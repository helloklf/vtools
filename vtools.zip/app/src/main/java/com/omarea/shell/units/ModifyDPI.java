package com.omarea.shell.units;

/**
 * Created by Hello on 2017/11/01.
 */

public class ModifyDPI {
    public void quickChangeDpi(int dpi, int width, int height) {

    }

    public void quickChangeDpi(int dpi) {

    }

    /*
    1 -> {
        stringBuilder.append(Consts.MountSystemRW)
        stringBuilder.append("sed '/ro.sf.lcd_density=/'d /system/build.prop > /data/build.prop\n")
        stringBuilder.append("sed '\$aro.sf.lcd_density=410' /data/build.prop > /data/build2.prop\n")
        stringBuilder.append("cp /system/build.prop /system/build.bak.prop\n")
        stringBuilder.append("cp /data/build2.prop /system/build.prop\n")
        stringBuilder.append("rm /data/build.prop\n")
        stringBuilder.append("rm /data/build2.prop\n")
        stringBuilder.append("chmod 0644 /system/build.prop\n")
        stringBuilder.append("wm size 1080x1920\n")
        stringBuilder.append("sync\n")
        stringBuilder.append("reboot\n")
    }
    2 -> {
        stringBuilder.append(Consts.MountSystemRW)
        stringBuilder.append("sed '/ro.sf.lcd_density=/'d /system/build.prop > /data/build.prop\n")
        stringBuilder.append("sed '\$aro.sf.lcd_density=440' /data/build.prop > /data/build2.prop\n")
        stringBuilder.append("cp /system/build.prop /system/build.bak.prop\n")
        stringBuilder.append("cp /data/build2.prop /system/build.prop\n")
        stringBuilder.append("rm /data/build.prop\n")
        stringBuilder.append("rm /data/build2.prop\n")
        stringBuilder.append("chmod 0644 /system/build.prop\n")
        stringBuilder.append("wm size 1080x1920\n")
        stringBuilder.append("sync\n")
        stringBuilder.append("reboot\n")
    }
    3 -> {
        stringBuilder.append(Consts.MountSystemRW)
        stringBuilder.append("sed '/ro.sf.lcd_density=/'d /system/build.prop > /data/build.prop\n")
        stringBuilder.append("sed '\$aro.sf.lcd_density=480' /data/build.prop > /data/build2.prop\n")
        stringBuilder.append("cp /system/build.prop /system/build.bak.prop\n")
        stringBuilder.append("cp /data/build2.prop /system/build.prop\n")
        stringBuilder.append("rm /data/build.prop\n")
        stringBuilder.append("rm /data/build2.prop\n")
        stringBuilder.append("chmod 0644 /system/build.prop\n")
        stringBuilder.append("wm size 1080x1920\n")
        stringBuilder.append("sync\n")
        stringBuilder.append("reboot\n")
    }
    */
}

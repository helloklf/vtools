#! /vendor/bin/sh

MODDIR=${0%/*}

log_file=/cache/lmkd_opt.log
function log()
{
    echo "$1" >> $log_file
}

# 清空日志
echo -n '' > $log_file

# 应用配置
sh /system/bin/scene_memory_config.sh >> $log_file 2>&1

log ""
log "fstrim"
busybox=/data/adb/magisk/busybox
if [[ -f $busybox ]]; then
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  sm fstrim
fi

log ""
log "全部完成！"

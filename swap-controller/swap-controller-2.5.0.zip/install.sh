SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"
  ui_print " "
  ui_print " 配置参数位于 /data/swap_config.conf 可自行修改 "
  ui_print " 或配合Scene3.4.6及以后的版本 "
  ui_print " 可直接在 SWAP设置 里调节模块配置"
  ui_print " "
  ui_print " "
}


set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}


origin_dir="/system/vendor/etc/perf"
origin_file="$origin_dir/perfconfigstore.xml"
overlay_dir="$MODPATH$origin_dir"
overlay_file="$MODPATH$origin_file"


old_module_file=/data/adb/modules/scene_swap_controller$origin_dir/perfconfigstore.xml
if [[ -e $old_module_file ]]; then
  old_module_version=`grep '^versionCode=' /data/adb/modules/scene_swap_controller/module.prop | cut -f2 -d '='`
  if [[ "$old_module_version" == "" ]] || [[ "$old_module_version" -lt 2000 ]]; then
    ui_print ''
    ui_print ''
    ui_print '请删除旧版模块并重启手机，回来再安装！'
    ui_print ''
    ui_print ''
    exit 2
  fi
fi


swap_config="/data/swap_config.conf"

swap_enable=false
swap_size=2047
swap_use_loop=false
zram_enable=true
zram_size=2047
auto_cgroup=false



# update_overlay ro.lmk.enhance_batch_kill false
update_overlay() {
  local prop="$1"
  local value="$2"
  sed -i "s/Name=\"$prop\" Value=\".*\"/Name=\"$prop\" Value=\"$value\"/" $overlay_file
}
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $TMPDIR/system.prop
}

get_prop() {
  cat $swap_config | grep "^$1=" | cut -f2 -d '='
}

# 解析旧版模块创建的配置（读取以便保留部分用户自定义配置）
read_current_config() {
  if [[ -f $swap_config ]]; then
    current_swap_enable=$(get_prop swap)
    current_swap_size=$(get_prop swap_size)
    current_swap_use_loop=$(get_prop swap_use_loop)
    current_zram_enable=$(get_prop zram)
    current_zram_size=$(get_prop zram_size)
    current_auto_cgroup=$(get_prop auto_cgroup)

    if [[ "$current_zram_enable" != "" ]] && [[ "$current_zram_size" != "" ]]; then
      zram_enable="$current_zram_enable"
      zram_size="$current_zram_size"
    fi
    if [[ "$current_swap_enable" != "" ]] && [[ "$current_swap_size" != "" ]]; then
      swap_enable="$current_swap_enable"
      swap_size="$current_swap_size"
    fi
    if [[ "$current_swap_use_loop" != "" ]]; then
      swap_use_loop="$current_swap_use_loop"
    fi
    if [[ "$current_auto_cgroup" != "" ]]; then
      auto_cgroup="$current_auto_cgroup"
    fi
  fi
}

# 根据设备性能自动调整参数
auto_config () {
  MemTotalStr=`cat /proc/meminfo | grep MemTotal`
  MemTotalKB=${MemTotalStr:16:8}
  ui_print "- RAM Total:${MemTotalKB}KB"


  # > 8GB
  if [[ $MemTotalKB -gt 8388608 ]]; then
    zram_enable="false"
    zram_size=128
  # > 6GB
  elif [[ $MemTotalKB -gt 6291456 ]]; then
    zram_enable="true"
    zram_size=3072
  # > 4GB
  elif [[ $MemTotalKB -gt 4194304 ]]; then
    zram_enable="true"
    zram_size=2047
  else
    zram_size=1536
  fi

  if [[ "$zram_enable" == "true" ]]; then
    ui_print "- ZRAM ON ${zram_size}MB"
  else
    ui_print "- ZRAM OFF"
  fi


  sdk_version=$(getprop ro.build.version.sdk)
  if [[ -f /dev/cpuset/top-app/tasks ]] && [[ "$sdk_version" -gt 27 ]]; then
    if [[ -d /sys/fs/cgroup/memory ]] || [[ -d /dev/memcg ]]; then
      module_3="/data/adb/modules/scene_cgroup"
      if [[ -d $module_3 ]] && [[ ! -f $module_3/remove ]] && [[ ! -f $module_3/disable ]]; then
        auto_cgroup="true"
        echo "" > $module_3/disable
        ui_print "- 当前模块已集成附加模块(三)全部功能"
        ui_print "- 已自动禁用附加模块(三)"
      elif [[ -f $swap_config ]] && [[ `grep 'auto_cgroup=true' $swap_config` != "" ]]; then
        auto_cgroup="true"
      fi
    fi
  fi
}

# 判断是否是特别喜欢杀后台的机型
check_peculiar_device () {
  device=$(getprop ro.product.vendor.name)
  manufacturer=$(getprop ro.product.vendor.manufacturer)
  platform=$(getprop ro.board.platform)

  peculiar_device="false"
  # Note: 2.4.0
  # mi 10 pro, mi 10, k30pro 这几个865机型比较特殊，
  # 后台应用oom_score_adj很容易变高超过900，导致很快被杀死
  # 因此针对机型适当的调整配置
  # if [[ "$device" == "cmi" ]] || [[ "$device" == "umi" ]] || [[ "$device" == "umi" ]]; then
  #   return 1
  # else
  #   return 0
  # fi

  # Note: 2.5.0
  # 小米865全系列机型，都特殊对待
  if [[ "$manufacturer" == "Xiaomi" ]] || [[ "$platform" == "kona" ]]; then
    return 1
  else
    return 0
  fi
}

ui_print ''
ui_print ''
ui_print "*******************************"

auto_config
read_current_config

ui_print "*******************************"
ui_print ''
ui_print ''

on_install() {
  ui_print "- 提取模块文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  echo "" > /data/swap_recreate

  echo "
# 是否启用swap
swap=$swap_enable

# swap大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=$swap_size

# swap使用顺序（0:与zram同时使用，-2:用完zram后再使用，5:优先于zram使用）
swap_priority=-2

# 是否挂载为回环设备(如非必要，不建议开启)
swap_use_loop=$swap_use_loop

# 是否启用zram
zram=$zram_enable

# zram大小(MB)，部分设备超过2047会开启失败
zram_size=$zram_size

# zram压缩算法(可设置的值取决于内核支持)
# lzo和lz4都很常见，性能也很好
comp_algorithm=lz4

# 使用zram、swap的积极性
# 不要设置的太低，避免在内存严重不足时才开始大量回收内存，导致IO压力集中。建议值30~100
swappiness=100

# 额外空余内存(kbytes)
extra_free_kbytes=25600

# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值。如果我有8G物理内存，那么回收10%就是一口气回收了大概800M，这个过程需要消耗不少性能，导致短时间卡住
# 但是设置太小也会导致swap因为每次回收的内存量太少而效率过低，出现连续的卡顿掉帧
# 因此，请酌情设置watermark_scale_factor
watermark_scale_factor=25

# 是否启用process_reclaim(Qualcomm特有)
# 按进程回收内存到SWAP/ZRAM，可有效的提高交换效率，但可能增加写入量(对SWAP来说)
# true : 开启，并根据ZRAM、SWAP配置微调
# false：关闭
enable_process_reclaim=false

# 拓展功能
# 调系统部分关键进程所属cgroup(cpu|memory)
# 这可能会提高系统响应性能，但可能增加耗电速度
auto_cgroup=$auto_cgroup
" > $swap_config
  device=$(getprop ro.product.vendor.name)
  manufacturer=$(getprop ro.product.vendor.manufacturer)
  platform=$(getprop ro.board.platform)

  check_peculiar_device
  peculiar_device=$?

  # 喜欢杀后台的特殊机型，特殊对待
  if [[ "$peculiar_device" == "1" ]]; then
    update_system_prop ro.lmk.medium 1001
    # 方式1 使用传统LMK
    update_system_prop ro.lmk.use_minfree_levels true

    # 方式2 降低PSI报告积极性
    # update_system_prop ro.lmk.psi_partial_stall_ms 350
  fi

  if [[ -f $origin_file ]]
  then
    mkdir -p $overlay_dir
    cp $origin_file $overlay_file

    update_overlay ro.lmk.kill_heaviest_task_dup false
    update_overlay ro.lmk.enhance_batch_kill false
    update_overlay ro.lmk.enable_watermark_check false
    update_overlay ro.lmk.enable_preferred_apps false

    # 喜欢杀后台的特殊机型，特殊对待
    if [[ "$peculiar_device" == "1" ]]; then
      update_overlay ro.lmk.super_critical 950
    else
      update_overlay ro.lmk.super_critical 800
    fi

    update_overlay ro.lmk.direct_reclaim_pressure 35
    update_overlay vendor.perf.gestureflingboost.enable true
    update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 120
  fi
}

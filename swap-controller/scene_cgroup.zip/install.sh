SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"
  ui_print " "
  ui_print " 本模块最佳适配系统版本 "
  ui_print " Android Q "
  ui_print " "
  ui_print " "
}


set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}


on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

version=$(getprop ro.build.version.sdk)
if [[ "$version" -lt 28 ]]; then
  ui_print "我淦，你这老古董系统，不支持，再见～"
  exit 2
fi

if [[ ! -f /dev/cpuset/top-app/tasks ]]; then
  ui_print "我淦，你这老古董内核，不支持，再见～"
  exit 3
fi

config_dir=""
config_path=""
config_dir1="/sys/fs/cgroup/memory"
config_dir2="/dev/memcg"
if [[ -d $config_dir1 ]]; then
  config_dir=$config_dir1
elif [[ -d $config_dir2 ]]; then
  config_dir=$config_dir2
else
  ui_print "我淦，你这老古董内核，不支持，再见～"
  exit 4
fi

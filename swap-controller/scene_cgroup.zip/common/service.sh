#! /vendor/bin/sh

MODDIR=${0%/*}

log_file=/cache/cgroup_opt.log
function log()
{
    echo "$1" >> $log_file
}

# 清空日志
echo -n '' > $log_file

# 应用配置
sh /system/bin/scene_cgroup.sh >> $log_file 2>&1


log ""
log "全部完成！"



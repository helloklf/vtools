#! /vendor/bin/sh

MODDIR=${0%/*}

lmkd_config="12800:0,16384:100,18432:200,20480:250,24576:900,32768:950"

setprop sys.lmk.minfree_levels "$lmkd_config"

log_file=/cache/lmkd_opt.log
function log()
{
    echo "$1" >> $log_file
}

# 清空日志
echo -n '' > $log_file

# 应用配置
sh /system/bin/scene_memory_config.sh >> $log_file 2>&1

# 某些参数设置过早可能会被系统覆盖掉，因此延后设置
sleep 15

log "设置LMK"
setprop sys.lmk.minfree_levels "$lmkd_config"
echo "12800,16384,18432,20480,24576,32768" > /sys/module/lowmemorykiller/parameters/minfree
echo 0 > /sys/module/lowmemorykiller/parameters/enable_lmk
echo 0 > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk

stop lmkd
start lmkd

log ""
log "fstrim"
busybox=/data/adb/magisk/busybox
if [[ -f $busybox ]]; then
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
fi

log ""
log "全部完成！"

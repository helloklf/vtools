SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# Construct your own list here
REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"
  ui_print " "
  ui_print " 配置参数位于 /data/swap_config.conf "
  ui_print " 可自行修改 "
  ui_print " "
  ui_print " 或配合Scene3.3.5及以后的版本 "
  ui_print " 可直接在 SWAP设置 里调节模块配置"
  ui_print " "
  ui_print " "
}

# Copy/extract your module files into $MODPATH in on_install.

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH/system 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# echo 1 > /data/swap_recreate
# if [[ ! -f /data/swap_config.conf ]]; then
echo "# 是否启用swap
swap=false
# swap大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=1024
# swap使用顺序（0:与zram同时使用，-2:用完zram后再使用，5:优先于zram使用）
swap_priority=-1
# 是否挂载为回环设备(如非必要，不建议开启)
swap_use_loop=false

# 是否启用zram
zram=false
# zram大小(MB)，部分设备超过2047会开启失败
zram_size=2047
# zram压缩算法(可设置的值取决于内核支持)
comp_algorithm=lzo

# 使用zram、swap的积极性
swappiness=100
# 额外空余内存(kbytes)
extra_free_kbytes=98304
" > /data/swap_config.conf
# fi

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"
  ui_print " "
  ui_print " 配置参数位于 /data/swap_config.conf 可自行修改 "
  ui_print " 或配合Scene3.4.6及以后的版本 "
  ui_print " 可直接在 SWAP设置 里调节模块配置"
  ui_print " "
  ui_print " "
}


set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}


origin_dir="/system/vendor/etc/perf"
origin_file="$origin_dir/perfconfigstore.xml"
overlay_dir="$MODPATH$origin_dir"
overlay_file="$MODPATH$origin_file"


old_module_file=/data/adb/modules/scene_swap_controller$origin_dir/perfconfigstore.xml
if [[ -e $old_module_file ]]
then
  ui_print ''
  ui_print ''
  ui_print '请删除旧版模块并重启手机，回来再安装！'
  ui_print ''
  ui_print ''
  exit 2
fi


# update_overlay ro.lmk.enhance_batch_kill false
update_overlay() {
  local prop="$1"
  local value="$2"
  sed -i "s/Name=\"$prop\" Value=\".*\"/Name=\"$prop\" Value=\"$value\"/" $overlay_file
}


zram_enable="true"
zram_size=2047

ui_print ''
ui_print ''
ui_print "*******************************"
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotalKB=${MemTotalStr:16:8}
ui_print "- RAM Total:${MemTotalKB}KB"



# > 8GB
if [[ $MemTotalKB -gt 8388608 ]]; then
  zram_enable="false"
  zram_size=128
# > 6GB
elif [[ $MemTotalKB -gt 6291456 ]]; then
  zram_enable="true"
  zram_size=3072
# > 4GB
elif [[ $MemTotalKB -gt 4194304 ]]; then
  zram_enable="true"
  zram_size=2047
else
  zram_size=1536
fi

if [[ "$zram_enable" == "true" ]]; then
  ui_print "- ZRAM ON ${zram_size}MB"
else
  ui_print "- ZRAM OFF"
fi
ui_print "*******************************"
ui_print ''
ui_print ''


on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  echo "" > /data/swap_recreate

  echo "
# 是否启用swap
swap=false

# swap大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=2047

# swap使用顺序（0:与zram同时使用，-2:用完zram后再使用，5:优先于zram使用）
swap_priority=-2

# 是否挂载为回环设备(如非必要，不建议开启)
swap_use_loop=false



# 是否启用zram
zram=$zram_enable

# zram大小(MB)，部分设备超过2047会开启失败
zram_size=$zram_size

# zram压缩算法(可设置的值取决于内核支持)
# lzo和lz4都很常见，性能也很好
comp_algorithm=lz4



# 使用zram、swap的积极性
# 不要设置的太低，避免在内存严重不足时才开始大量回收内存，导致IO压力集中。建议值30~100
swappiness=100



# 额外空余内存(kbytes)
extra_free_kbytes=25600



# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值。如果我有8G物理内存，那么回收10%就是一口气回收了大概800M，这个过程需要消耗不少性能，导致短时间卡住
# 但是设置太小也会导致swap因为每次回收的内存量太少而效率过低，出现连续的卡顿掉帧
# 因此，请酌情设置watermark_scale_factor
watermark_scale_factor=25



# lmk 此模块默认设置为
#   15m  20m  32m   40m   64m   96m
#   4096 5120 8192 10240 16384 24576

#   非Android Q+的
lmk_minfree_levels=4096,5120,8192,10240,16384,24576

#   Android Q+的
lmk_minfree_levels_q=4096:0,5120:100,8192:200,10240:250,16384:900,24576:906

# 是否启用process_reclaim(Qualcomm特有)
# 按进程回收内存到SWAP/ZRAM，可有效的提高交换效率，但可能增加写入量(对SWAP来说)
# true : 开启，并根据ZRAM、SWAP配置微调
# false：关闭
enable_process_reclaim=true
" > /data/swap_config.conf


  if [[ -f $origin_file ]]
  then
    mkdir -p $overlay_dir
    cp $origin_file $overlay_file

    update_overlay ro.lmk.kill_heaviest_task_dup false
    update_overlay ro.lmk.enhance_batch_kill false
    update_overlay ro.lmk.enable_watermark_check false
    update_overlay ro.lmk.enable_preferred_apps false
    update_overlay ro.lmk.super_critical 906
    update_overlay ro.lmk.direct_reclaim_pressure 35
    update_overlay vendor.perf.gestureflingboost.enable true
    update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 120
  fi
}

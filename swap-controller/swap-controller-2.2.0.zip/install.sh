SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

print_modname() {
  ui_print "*******************************"
  ui_print "     Module author: 嘟嘟ski    "
  ui_print "*******************************"
  ui_print " "
  ui_print " 配置参数位于 /data/swap_config.conf 可自行修改 "
  ui_print " 或配合Scene3.4.6及以后的版本 "
  ui_print " 可直接在 SWAP设置 里调节模块配置"
  ui_print " "
  ui_print " "
}


set_permissions() {
  set_perm_recursive $MODPATH/system 0 0 0755 0644
}


origin_dir="/system/vendor/etc/perf"
origin_file="$origin_dir/perfconfigstore.xml"
overlay_dir="$MODPATH$origin_dir"
overlay_file="$MODPATH$origin_file"


old_module_file=/data/adb/modules/scene_swap_controller$origin_dir/perfconfigstore.xml
if [[ -e $old_module_file ]]
then
  echo ''
  echo ''
  echo '请删除旧版模块并重启手机，回来再安装！'
  echo ''
  echo ''
  exit 2
fi


# update_overlay ro.lmk.enhance_batch_kill false
update_overlay() {
  local prop="$1"
  local value="$2"
  busybox sed -i "s/Name=\"$prop\" Value=\".*\"/Name=\"$prop\" Value=\"$value\"/" $overlay_file
}

zram_best_size=2047
zram_enable=true
swap_best_size=2047
swap_enable=false
swap_priority=0

ui_print ''
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotalGB=$((${MemTotalStr:16:8} / 1024 / 1024 + 1))

# 大概猜测CPU的性能水平
cpu_score=1

# /sys/devices/system/cpu/cpufreq/policy0
#
cpufreq='/sys/devices/system/cpu/cpufreq'

# 4+3+1
if [[ -f $cpufreq/policy4/cpuinfo_max_freq ]] && [[ -f $cpufreq/policy7/cpuinfo_max_freq ]]; then
  cpu_score=$(($cpu_score + 4))
# 4+2+2
elif [[ -f $cpufreq/policy4/cpuinfo_max_freq ]] && [[ -f $cpufreq/policy6/cpuinfo_max_freq ]]; then
  cpu_score=$(($cpu_score + 4))
# 6+1+1
elif [[ -f $cpufreq/policy6/cpuinfo_max_freq ]] && [[ -f $cpufreq/policy7/cpuinfo_max_freq ]]; then
  cpu_score=$(($cpu_score + 2))
# 6+2
elif [[ -f $cpufreq/policy6/cpuinfo_max_freq ]]; then
  cpu_score=$(($cpu_score + 1))
# 4+4
elif [[ -f $cpufreq/policy4/cpuinfo_max_freq ]]; then
  freq=`cat $cpufreq/policy4/cpuinfo_max_freq`
  # 大核频率高于2.5Ghz (低功耗架构一般是到不了这个频率的)
  if [[ $freq -gt 2500000 ]]; then
    cpu_score=$(($cpu_score + 3))
  # 大核频率高于2.35Ghz (低功耗架构一般是到不了这个频率的)
  elif [[ $freq -gt 2350000 ]]; then
    cpu_score=$(($cpu_score + 2))
  # 大核频率高于2.2Ghz
  elif [[ $freq -gt 2200000 ]]; then
    cpu_score=$(($cpu_score + 1))
  fi
fi

if [[ $cpu_score -gt 4 ]]; then
  swap_enable=true
elif [[ $cpu_score -lt 4 ]]; then
  swap_priority=-2
# 性能警告
elif [[ $cpu_score -lt 3 ]]; then
  ui_print '你的手机处理器看上去有点弱'
  ui_print '使用ZRAM、SWAP体验将不会太好~'
fi

if [[ "$MemTotalGB" != "" ]]; then
  ui_print ''
  ui_print "RAM Total: ${MemTotalGB}GB"
  ui_print ''

  # >= 12GB
  if [[ $MemTotalGB -gt 11 ]]; then
    zram_enable=false
    swap_enable=false
  # < 3GB
  elif [[ $MemTotalGB -lt 3 ]]; then
    zram_best_size=1024
  fi
fi


if [[ "$swap_enable" == "true" ]]; then
  ui_print '- 预设为 SWAP-ON' ${swap_best_size}MB
else
  ui_print '- 预设为 SWAP-OFF'
fi

if [[ "$zram_enable" == "true" ]]; then
  ui_print '- 预设为 ZRAM-ON' ${zram_best_size}MB
else
  ui_print '- 预设为 ZRAM-OFF'
fi

ui_print ''

on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  echo "" > /data/swap_recreate

  echo "
# 是否启用swap
swap=$swap_enable

# swap大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=$swap_best_size

# swap使用顺序（0:与zram同时使用，-2:用完zram后再使用，5:优先于zram使用）
swap_priority=$swap_priority

# 是否挂载为回环设备(如非必要，不建议开启)
swap_use_loop=false



# 是否启用zram
zram=$zram_enable

# zram大小(MB)，部分设备超过2047会开启失败
zram_size=$zram_best_size

# zram压缩算法(可设置的值取决于内核支持)
# lzo和lz4都很常见，性能也很好
comp_algorithm=lzo



# 使用zram、swap的积极性
# 不要设置的太低，避免在内存严重不足时才开始大量回收内存，导致IO压力集中。建议值30~100
swappiness=100



# 额外空余内存(kbytes)
extra_free_kbytes=35958



# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值。如果我有8G物理内存，那么回收10%就是一口气回收了大概800M，这个过程需要消耗不少性能
# 因此，请酌情设置watermark_scale_factor
watermark_scale_factor=25



# lmk 此模块默认设置为
#   15m  20m  32m   40m   64m   96m
#   4096 5120 8192 10240 16384 24576

#   非Android Q+的
lmk_minfree_levels=4096,5120,8192,10240,16384,24576

#   Android Q+的
lmk_minfree_levels_q=4096:0,5120:100,8192:200,10240:250,16384:900,24576:906

# 是否启用process_reclaim(Qualcomm特有)
# 在内存充足时预先交换部分数据到SWAP/ZRAM，避免在需要内存时才进行交换耗费大量时间
# auto : 根据SWAP、ZRAM容量自动决定是否启用
# true : 始终开启
# false：始终关闭
enable_process_reclaim=auto

# 是否启用白名单
# 白名单里的应用会尽量避免使用swap、zram，从而提高这些应用的流畅性，例如：系统桌面、SystemUI
# 此特性需要内核支持
white_list_enable=true
" > /data/swap_config.conf


  if [[ -f $origin_file ]]
  then
    mkdir -p $overlay_dir
    cp $origin_file $overlay_file

    update_overlay ro.lmk.kill_heaviest_task_dup false
    update_overlay ro.lmk.enhance_batch_kill false
    update_overlay ro.lmk.enable_watermark_check false
    update_overlay ro.lmk.enable_preferred_apps false
    update_overlay ro.lmk.super_critical 906
    update_overlay ro.lmk.direct_reclaim_pressure 30
    # update_overlay vendor.perf.gestureflingboost.enable false
    update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 120
  fi
}
